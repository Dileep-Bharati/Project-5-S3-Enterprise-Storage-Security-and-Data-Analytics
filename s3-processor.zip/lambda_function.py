import boto3
import json
import os
import logging
from datetime import datetime
from urllib.parse import unquote_plus

logger = logging.getLogger()
logger.setLevel(logging.INFO)
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
sns = boto3.client('sns')

SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN', '')
TRACKING_TABLE = os.environ.get('TRACKING_TABLE', '')

def lambda_handler(event, context):
    logger.info(f"Received event: {json.dumps(event)}")
    for record in event.get('Records', []):
        event_name = record.get('eventName', '')
        bucket = record['s3']['bucket']['name']
        key = unquote_plus(record['s3']['object']['key'])
        size = record['s3']['object'].get('size', 0)
        timestamp = datetime.utcnow().isoformat()
        
        if TRACKING_TABLE:
            table = dynamodb.Table(TRACKING_TABLE)
            table.put_item(Item={
                'file_key': key,
                'event_timestamp': timestamp,
                'event_name': event_name,
                'bucket_name': bucket,
                'file_size': size
            })
    return {'statusCode': 200, 'body': 'Processed Successfully'}
